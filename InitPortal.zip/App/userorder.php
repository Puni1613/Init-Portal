	<?php
if(isset($_POST["sub"]))
{

	$con=new mysqli("localhost","root","punithkumar","Project");
	  if(!$con)
	   {
        die('could not connect'.mysqli_error());
    	}
    	$username=$_POST["username"];
    	$password=$_POST["password"];
     $res=$con->query("select * from userlists where Username='$username'");
     $row=$res->fetch_assoc();
     if($username==$row["Username"])
     {
     	
     	$email=$row["Email"];
     	$phone=$row["phone"];
     	$res=$con->query("Select * from userslocations");
     	$row1=$res->fetch_assoc();
     	$Lang=$row1["Lang"];

     	$Lat=$row1["Lat"];
     	  $res1=$con->query("Select * from userlogins where Email='$email'");
     	$row11=$res1->fetch_assoc();
     	$username1=$row11["Name"];
     	session_start();
     	$_SESSION["username"]=$username1;
		$_SESSION["email"]=$email;
		$_SESSION["phone"]=$phone;
		$_SESSION["lat"]=$Lat;
		$_SESSION["lang"]=$Lang;
		header('location:usermainlist1.php');
	}
	else
		{
			echo '<script type="text/javascript">';
			echo 'alert("Invalid Password TRY AGAIN!!!")';
			echo '<script>';
			
		}
	}	

?>