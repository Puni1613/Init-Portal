 
    <script type="text/javascript">
    public function test()
    {
        alert('In test Function');
    }
    </script>
<?php
$name=$_POST["name1"];
$unid=$_POST["unid"];
$waste=$_POST["what"];
$ton=$_POST["ton"];
$address=$_POST["address"];
$city=$_POST["city1"];
$zip=$_POST["zip1"];
$company=$_POST["company1"];
$phone=$_POST["phone1"];
$email=$_POST["email1"];
$website=$_POST["website1"];
$str1=$address.$city;
 $string = str_replace (" ", "+", urlencode($str1));
$geocode=file_get_contents("http://maps.google.com/maps/api/geocode/json?address=".$string."&sensor=false");

$output= json_decode($geocode);

$lat = $output->results[0]->geometry->location->lat;
$long = $output->results[0]->geometry->location->lng;
$con=new mysqli("localhost","root","punithkumar","Project");
    if(!$con) {
        die('could not connect'.mysqli_error());
    }
 $sql="INSERT INTO vendorlocations(Name,Waste,Email,Lang,Lat) VALUES ('$name','$waste','$email','$long','$lat')";
$con->query($sql);
$sql1="INSERT INTO vendorslogins(Name,VendorID,Waste,Capacity,Adress,City,Zip,Phone,Company,Website,Email) VALUES('$name','$unid','$waste','$ton','$address','$city','$zip','$phone','$company','$website','$email')";
  $res1=$con->query($sql1);
 
  session_start();
  $_SESSION["Email1"]=$email;
  $_SESSION["Phone1"]=$phone;

if($res1)
{   
 function PHPFunction()
    {
            echo '<script type="text/javascript">
                 test();
            </script>'; 
    }	
header('location:checkloginvendors.php');
 }
else
{   
 header('location:registers.php');
}
$con->close();

?>