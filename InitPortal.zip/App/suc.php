<?php
$servername = "localhost";
$username = "root";
$password = "punithkumar";
$db="MCA1";
$names=$_POST["name"];
$usnn=$_POST["usn"];
$deptt=$_POST["dept"];
// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
$sql="INSERT INTO Rec(usn,name,dept) VALUES('$usnn','$names','$deptt')";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();

?>
