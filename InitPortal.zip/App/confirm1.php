<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>ORDER</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
      #map {
        width: 300px;
        height: 500px;
      }
    </style>
    <script type="text/javascript">
   
         function check()
            {  var stringf= document.getElementById("us1").value;
             var Stringdate=document.getElementById("usn2").value;

               
            if(!form1.time.value)
                {
                  alert("Please Enter the address befor submit!!! ")
                   return (false);
                }
                if(!form1.date.value)
                {
                  alert("Please Enter the address befor submit!!! ")
return(false);
                }
               
                return (true);
            }
            </script>
      <script type="text/javascript">


</script>
  </head>

  <body>
                <nav class="navbar navbar-inverse navbar-fixed-left" role="navigation"> 
                <div class="container">
                    <ul class="nav nav-pills pull-left">
                    <li ><a class="navbar-brand" href="usermainpage.html" id="def">YOUR PAGE</a></li>
                            
                  </ul>
                </div>
              </nav>
    
            <div class="blog-header">
           <div class="container">
        <div  class="col-sm-10 form-group">
    
        <h1 class="blog-title">Order Transposal</h1>
        <p class="lead blog-description">Vendor selection process</p>
        </div>
      <div  class="col-sm-2 form-group">
      <!--<img width="160" height="80" src="#"/> -->
        </div>
      </div></div>

<div class="container">
</br>
      <div class="row">
    <div class="col-md-10">
           <form method="post" name="form1" action="confirm2.php" >



            <div  class="col-sm-6 form-group">
                <label><h4>Email</h4></label>
                <input type="text" name="mail" value="<?php session_start(); echo($_SESSION['email']);?>" class="form-control" >
              </div>  
            
              <div  class="col-sm-6 form-group">
               <label for="sel1"><h4>KIND OF WASTE</h4></label>
                 <select class="form-control" name="what" id="sel1">
                      <option>Dry Waste</option>
                     <option> Wet Waste</option>
                      <option>E-Waste</option>
                     <option>Medical waste</option>
                 </select>
                 </div>
              <div  class="col-sm-6 form-group">
              <label for="sel1"><h4>WASTE APPROXIMATE</h4></label>
                 <select class="form-control" name="size" id="sel1">
                     <option> 10-20</option>
                      <option>30-40</option>
                     <option>40-50</option>
                     <option>50+</option>
                 </select>
                 </div>
            
            
              <div  class="col-sm-6 form-group">
                <label><h4>OderID</h4></label>
                <input type="text"  name="ord" value="<?php $digit=5; echo rand(pow(10,$digit-1),pow(10,$digit)-1); ?>" class="form-control">
                </div>
              <div  class="col-sm-6 form-group" class="form-control">
              <label><h4>Date</h4></label>
              <input type="date" name="date" id="usn1" placeholder="DD/MM/YYYY" class="form-control" >
              </div>
             <div  class="col-sm-6 form-group">
             <label><h4>TIME</h4></label> <br>
             <input type="time" id="t1" name="time" id="usn2" placeholder="9 AM to 6 PM" class="form-control">
             </div>

             
             <div class="col-sm-12 form-group">
             <button type="submit"  name="confirm"  class="col-sm-12 form-group" >CONFIRM</button>
             </div>
           </form>
</div>
<div class="col-md-2">
         
      </div><!-- /.row -->

    </div><!-- /.container -->

    <footer class="blog-footer">
      <p>InIt protal <a href="http://localhost/App/image.html"></p>
      <p>
        <a href="#">follow us</a>
      </p>
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
