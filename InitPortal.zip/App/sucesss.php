<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>REGISTRATION INFO</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css" >
        <script src="js/bootbox.min.js" ></script>
			
	</head>
	<body>
	<?php

  
  if(isset($_POST["sub"]))
  {
    $username=$_POST["username"];
    $email=$_POST["name"];
    $phone=$_POST["phone"];
    $password=$_POST["passwd"];

      $con=new mysqli("localhost","root","punithkumar","Project");
        if(!$con) {
        die('could not connect'.mysqli_error());
          }
  
      $sql="INSERT INTO userlists(Email,Username,password,phone) VALUES('$email','$username','$password','$phone')";
      $result=$con->query($sql);

         if($result)
         {
           echo '<script type="text/javascript">alert("sucessfull")</script>';
          header('location:image.html');
         }
         else
          {
      echo '<script type="text/javascript">alert("Unsucessful")</script>';
         header('location:registers.html');

         }
         $con->close();
       }
      
     ?>
		<!-- jQuery -->
		<script src="jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js" >
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>