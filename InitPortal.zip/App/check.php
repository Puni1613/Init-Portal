
<?php 

$m=new Mongo();
echo "connecttion established";
$db=$m->selectDB("demo");
echo "data entered";
$collection=$db->selectCollection("Example");
$c=array("Name"=>"punith");
$collection->insert($c);
echo "inserted";

?>