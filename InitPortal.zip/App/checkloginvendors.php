<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>VendorsLoginStatus</title>

<link rel="stylesheet" href="css/bootstrap.min.css" ></head>
	<body>
	

	 <nav class="navbar navbar-default navbar-fixed-left" role="navigation"> 
		 	<div class="container">
		 		<ul class="nav navbar-nav">
					<li >
						<h3><a href="#" id="a">Vendors DETAILS</a><h3>
					</li>
				</ul>
			 <a href="image.html"><h3 class="text-right">INIT PORTAL</h3></a>	
		</div>
		</nav>
			<div class="container">
		
 	 <div class="col-sm-12">

    		<div class="row">
		
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
					  <label> Registration</label>
				
					<form action="sucess2.php" method="post">
					


					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Email</label>
								<input type="text" value="<?php session_start(); echo($_SESSION["Email1"]);?>" name="name" class="form-control">
							</div>
						</div>					
					</div>		
  					


  					 <div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Phone</label>
								<input type="text" name="phone"  value="<?php  echo($_SESSION["Phone1"]); ?>" class="form-control">
							</div>
						</div>	
					</div>



					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> USERNAME</label>
								<input type="" placeholder="Enter username"  name="username" class="form-control">
							</div>
						</div>	
					</div>
					



					 <div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> PASSWORD</label>
								<input type="password" placeholder="Enter password"  name="passwd" class="form-control">
							</div>
						</div>	
					</div>
					<div>
					<input  type="submit" value="SUBMIT" name="subm"  class="btn btn-lg btn-info" /></div>	
    
</form>
</div>

		<!-- jQuery -->
		<script src="jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js" ></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>