<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Theme Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/theme.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">
    <link rel="stylesheet" type="text/css" href="css/navbar-static-top.css">
    <script src="js/ie-emulation-modes-warning.js"></script>
    <script type="text/javascript">
      function check()
      {

        alert("You are sucessfully logged out");
      }

    </script>
    <style type="text/css">
   #one {
        width: 700px;
        height: 400px;
      }
      </style>


    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body role="document">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="image.html" onclick="check()">INIT-PORTAL</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">YOU</a></li>
             <li><a href="confirm1.php">BOOK YOUR ORDER</a></li>
            <li><a href="Vendorlist.php">VENDORSLIST</a></li>
            <li><a href="mar.php">VENDORLOCATION</a></li>
             <li><a href="Rules.php">WASTE CHARGES</a></li>
            
          </ul>
          <ul class="nav nav-pills pull-right">
          <li><a href="image.html" onclick="check()">Log out</a></li></ul>
                  </div><!--/.nav-collapse -->
      </div>
    </nav>
     <!-- Main jumbotron for a primary marketing message or call to action -->
     <div class="container">
      <div class="jumbotron">
        <h1>Welcome <?php session_start(); echo($_SESSION["username"]);?></h1>
        <p> Init portal.com is a specially developed web-based software program,designed and developed by evolution.It's built around your waste management needs,providing you with live and instant access to all of your data and needs .</p>
      </div>
      </div>
   <div class="container">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <div class="row">
              <div class="col-sm-6 form-group">
                <div id="one">
            <img src="images/3.jpg">
            </div>
        
              </div>
               <div class="col-sm-6 form-group">
<p>
                          Our service is professionalizing the informal sector for greater livelihood and environmental impact, linking waste pickers and scrap dealers to multinational companies. We collect a variety of dry waste types.
              Benefits to the customer:
              Transparent pricing: better prices for greater volumes, rather specific prices for a specific customers
              Timely pickup, timely payment: your waste picked up at your convenience with on-time payment
              Fair labor and safe environmental practices: your waste is processed in an eco-friendly manner by workers receiving fair compensation
            </p>
            <p>
              Init Portal 'SwachhWorks' solution includes professional doorstep collection of waste, scientific and eco-friendly on-site processing of organic waste (e.g. kitchen waste), and recycling of dry/recyclable waste, reducing the waste out of the gate by up to 90%.</blockquote>


Benefits of our Urban Waste Management service include:
Greener footprint: reduce up to 90% of waste that would normally be landfilled; plus, be confident that any less valuable waste is not just trashed in the nearest open plot
Citizen engagement: residents or employees can learn about green initiatives such as composting and recycling directly from our website.
            </p>
              </div>
            </div>  
            </div>    

   


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
