<?php

$connection=new mysqli ('localhost', 'root', 'punithkumar','Project');
if (!$connection) {
  die('Not connected : ' . mysql_error());
}

$mydata=array();
$post=array();
// Select all the rows in the markers table
$query = "SELECT * FROM vendorlocations";
$result = $connection->query($query);

?>
<?php
while ($row=$result->fetch_assoc())
{
$Name=$row['Name'];
$email=$row['Email'];
$waste=$row['Waste'];
$lat=$row['Lat'];
$lang=$row['Lang'];

$post[]=array('Name'=>$Name,'Email'=>$email,'Waste'=>$waste,'Lat'=>$lat,'Lang'=>$lang);
}
$mydata['post']=$post;
$myfile="res.json";
$fp = fopen($myfile, 'w');
fwrite($fp, json_encode($mydata));
fclose($fp);

?>

