<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>UsersLoginStatus</title>

<link rel="stylesheet" href="css/bootstrap.min.css" ></head>
	<body>

	 <nav class="navbar navbar-default navbar-fixed-left" role="navigation"> 
		 	<div class="container">
		 		<ul class="nav navbar-nav">
					<li >
						<h3><a href="#" id="a">USER DETAILS</a><h3>
					</li>
				</ul>
			 <a href="image.html"><h3 class="text-right">INIT PORTAL</h3></a>	
		</div>
		</nav>
		
		<div class="container">
		
 	 <div class="col-sm-12">

    		<div class="row">
		
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
					  <label> Registration</label>
					<form action="sucesss.php" method="post">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Email</label>
								<input type="text" value="<?php session_start(); echo($_SESSION["Email_ID"]);?>" name="name" class="form-control">
							</div>
						</div>	
					</div>		
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Phone</label>
								<input type="text" value="<?php  echo($_SESSION["Phone"]);?>" name="phone" class="form-control">
							</div>
						</div>	
					</div>		
  				<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> USERNAME</label>
								<input type="text" placeholder="Username ex.prahasan"  name="username" class="form-control">
							</div>
						</div>	
					</div>
					 <div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> PASSWORD</label>
								<input type="password" id="pass1" placeholder="password atleast 6 characeter"  name="passwd"  style="border-radius:7px; border:2px solid #dadada;" class="form-control">
							</div>
						</div>	
					</div>
					 
					<div>
					<input  type="submit" value="SIGN UP"  name="sub" class="btn btn-lg btn-info" /></div>	
    
</form>
</div>


		<!-- jQuery -->
		<script src="jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js" ></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>
