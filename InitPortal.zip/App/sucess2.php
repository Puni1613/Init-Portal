<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>REGISTRATION INFO</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" >

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
        <script src="js/bootbox.min.js" ></script>
      
  </head>
  <body>
  <?php
  if(isset($_POST["subm"]))
  {
    $username=$_POST["username"];
    $email=$_POST["name"];
    $password=$_POST["passwd"];
   $phone=$_POST["phone"];
      $con  = new mysqli("localhost","root","punithkumar","Project");
        if(!$con) {
        die('could not connect'.mysqli_error());
          }
     $rs="INSERT INTO vendorlists(Email,Phone,username,Password) VALUES('$email','$phone','$username','$password')";
         $stand=$con->query($rs);
         if($stand)
         {
          echo '<script type="text/javascript">';
           echo 'alert("sucessfull")';
          echo '</script>';
          header('location:image.html');
         }
         else
         {        
           echo '<script type="text/javascript">';
        echo 'alert("unsucessfull ")';
      echo '</script>';
      header('location:registers.html');

         }
       }
  
   ?>
    <!-- jQuery -->
    <script src="jquery.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
     <script src="Hello World"></script>
  </body>
</html>