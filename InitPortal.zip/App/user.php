<?php 
session_start();
?>
<?php 
/*if(isset($_POST['submit']))
{
	$name=ucfirst($_POST["name"]);
$exprr="/[a-z][A-z]+ \. + *[A-Z]/";
if(preg_match($exprr, name))
{
print(<script type="text/javascript">alert("Invalid Name")</script>);

}*/	


$address= ucfirst($_POST["address"]);
$city=$_POST["city"];
$zip=$_POST["zip"];
$company=$_POST["company"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$website=$_POST["website"];
$str1=$address.$city;
 $string = str_replace(" ", "+", urlencode($str1));
$geocode=file_get_contents("http://maps.google.com/maps/api/geocode/json?address=".$string."&sensor=false");

$output= json_decode($geocode);

$lat = $output->results[0]->geometry->location->lat;
$long = $output->results[0]->geometry->location->lng;
$con=new mysqli("localhost","root","punithkumar","Project");
    if(!$con) {
        die('could not connect'.mysqli_error());
    }
$sql = "INSERT INTO userslocations(Name,Email,Lang,Lat) VALUES ('$name','$email','$long','$lat')";
 
$sql1="INSERT INTO userlogins(Name,Adress,City,Zip,Phone,Company,Website,Email) VALUES('$name','$address','$city','$zip','$phone','$company','$website','$email')";
    $con->query($sql);

	
	$_SESSION["Email_ID"]=$email;
    $_SESSION["Phone"]=$phone;
    $res=$con->query($sql1);

if($res)
{
   header('location:checklogin.php');
}
$con->close();


?>