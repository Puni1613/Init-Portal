<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Multiple logins</title>
		<style type="text/css">

			#aa
			{
				color: #ff0000;
			}

			#bb
			{
				display: none;
			}
		</style>
		<script src="jquery.js"></script>

		<script type="text/javascript">
		 function check()
            {  var stringf= document.getElementById("us1").value;
                if (!form1.name.value)
                {
                    alert ("Please Enter Name Before submit");
                    return (false);
                }
               
            if(!form1.address.value)
                {
                	alert("Please Enter the address befor submit!!! ")

                }
                if(!form1.phone.value)
                {
                	alert("Please Enter the address befor submit!!! ")

                }
                if(!form1.email.value)
                {
                	alert("Please Enter the address befor submit!!! ")

                }
                return (true);
            }
           
			$(document).ready(function(){
			    $("#a").click(function(){
			    		$("#aa").show();
			            $("#bb").hide();
			        });
			});

			$(document).ready(function(){
			    $("#b").click(function(){
			            $("#aa").hide();
			            $("#bb").show();
			        });
			});

		</script>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		 <nav class="navbar navbar-default navbar-fixed-left" role="navigation"> 
		 	<div class="container">
				<ul class="nav navbar-nav">
					<li >
						<a href="#" id="a"><h3>Users Registration</h3></a>
					</li>
					<li>
						<a href="#" id="b"><h3>vendors registration</h3></a>
					</li>
				</ul>
				 <a href="image.html"><h3 class="text-right">INIT PORTAL</h3></a>
		</div>
		</nav>		 
				<div class="container" id="aa">
		  <div class="col-lg-12 well">
		<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					  <label> Users Registration Form</label>
					<form name="form1" action="user.php" method="post">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Name</label>
							
								<input type="text"  autocomplete="off" placeholder="Enter First Name Here.." id="us1" name="name" data-validate="required,text" class="form-control">
							</div>
						</div>					
						<div class="form-group">
							<label>Address</label>
							<input type=text placeholder="Enter Address Here.." name="address" rows="3" id="us2" data-validate="required,text" class="form-control">
						</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>City</label>
								<input type="text" placeholder="Enter City Name Here.." name="city" id="us3"  data-validate="required,alphanumeric" class="form-control">
							</div>	
							<div class="col-sm-4 form-group">
								<label>Zip</label>
								<input type="text" placeholder="Enter Zip Code Here.."  name="zip" id="us4" data-validate="required,number" class="form-control">
							</div>		
						</div>
						<div class="row">	
							<div class="col-sm-6 form-group">
								<label>Company</label>
								<input type="text" placeholder="Enter Company Name Here.." name="company" id="us5" data-validate="text" class="form-control">
							</div>	
						</div>						
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" placeholder="Enter Phone Number Here.." name="phone" id="us6" data-validate="required,phone" class="form-control">
					</div>		
					<div class="form-group">
						<label>Email Address</label>
						<input type="text" placeholder="Enter Email Address Here.." name="email" id="us7" data-validate="required,email" class="form-control">
					</div>	
					<div class="form-group">
						<label>Website</label>
						<input type="text" placeholder="Enter Website Name Here.." name="website" id="us8" class="form-control">

					</div>
					<div>
					<input  type="submit" value="SUBMIT USER ENTRY" id="s" name="sub1" onclick="check()" class="btn btn-lg btn-info" /></div>
										
					</div>
				</form> 
				</div>
				</div>
		</div>
		</div>	

			<div class="container" id="bb">
		<div class="col-lg-12 well">
		<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<label>Vendors Registration Form</label>
		<form action="vendor.php" method="post">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Name</label>
								<input type="text" placeholder="Enter  Name Here.."  name="name1" data-validate="required,text" class="form-control">
							</div>
						</div>		
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Vendors Unique ID</label>
								<input type="text" placeholder="Enter City Name Here.." name="unid" data-validate="required,regex(BBMP-SWM,INAVLID ID)" class="form-control">
							</div>	
							</div>
							<div class="row">
							 <div class="col-sm-4 form-group">
								  <label for="sel1">Select Waste Type:</label>
 								 <select class="form-control" name="what" id="sel1">
  									  <option>Dry Waste</option>
   									 <option> Wet Waste</option>
  									  <option>E-Waste</option>
   									 <option>Medical waste</option>
 								 </select>
 						</div>		
 						</div>	
                         	<div class="row">
							 <div class="col-sm-4 form-group">
								  <label for="sel1">Processing Capacity(in tons):</label>
 								<input type="number" name="ton"  data-validate="required,number">
 								
 						</div>		
 						</div>	
						<div class="form-group">
							<label>Address</label>
							<textarea placeholder="Enter Address Here.." name="address" rows="3"  class="form-control"></textarea>
						</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Zip</label>
								<input type="text" placeholder="Enter Zip Code Here.."  name="zip1" data-validate="required,number" class="form-control">
							</div>		
						</div>
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>City</label>
								<input type="text" placeholder="Enter City Name Here.." name="city1" data-validate="required,text" class="form-control">
							</div>	
						</div>
						<div class="row">	
							<div class="col-sm-6 form-group">
								<label>Company</label>
								<input type="text" placeholder="Enter Company Name Here.." name="company1" data-validate="required,text" class="form-control">
							</div>	
						</div>						
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" placeholder="Enter Phone Number Here.." name="phone1" data-validate="required,number" class="form-control">
					</div>		
					<div class="form-group">
						<label>Email Address</label>
						<input type="text" placeholder="Enter Email Address Here.." name="email1" data-validate="required,email" class="form-control">
					</div>	
					<div class="form-group">
						<label>Website</label>
						<input type="text" placeholder="Enter Website Name Here.." name="website1"  class="form-control">

					</div>
					<div>
					<input  type="submit" value="SUBMIT VENDORS DETAILS" name="sub2" id="press1" class="btn btn-lg btn-info" /></div>
										
					

				</form> 
		</div>
				</div>
				</div>
				</div>


		<!-- jQuery -->
		
		<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		<script src="jquery.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
<!-- Verify.js (with Notify.js included) -->
<script src="https://rawgit.com/jpillora/verifyjs/gh-pages/dist/verify.notify.min.js"></script>
	</body>
</html>
