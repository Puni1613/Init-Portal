<?php
$conn=new mysqli("localhost","root","punithkumar","Project");
if(!$con) {
        die('could not connect'.mysqli_error());
    }
 
 $collection=$db->selectCollection("vendorlists");

 $name=$_POST["username"];
 $password=$_POST["password"];
 $user=$collection->find(array("username"=>$name,"password"=>$password));
$user->limit(1);
session_name("Session3");
	session_start();
	$_SESSION["Email1"]=$user['Email'];
	
if($user->count(true)>0)
{  
	echo "<script type="javascript/text">";
	echo "alert('welcome $username ');";
	echo "</script>";
	header('location:con.php');

}
else
{
	echo "<script type="javascript/text">";
	echo "alert('welcome $username ');";
	echo "</script>";
	header('location:Order1.html');
}
?>