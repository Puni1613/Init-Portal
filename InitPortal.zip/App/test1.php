<?php 
	$name = "akshay";
	$email = "qq";
	$long = "sfghjhg";
	$con=mysqli_connect("localhost","root","punithkumar","MCA1");
    if(!$con) {
        die('could not connect'.mysqli_error());
    }
	$sql = "INSERT INTO Rec(usn,name,dept) VALUES (\"$name\",\"$email\",\"$long\")";
	echo $sql;
	$res=mysqli_query($con,$sql);
	echo $res;
	if($res)
	{
		echo "inserted";
	}
 ?>